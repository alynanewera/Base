const fs = require('fs');
const readline = require('readline');
const path = require('path');
const { exec } = require('child_process');
const chalk = require('chalk');
const ora = require('ora'); // Untuk animasi loading

// Membuat interface untuk membaca input dari pengguna
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Fungsi untuk mendapatkan input dari pengguna
function getInput(prompt) {
    return new Promise((resolve) => {
        rl.question(prompt, (answer) => resolve(answer));
    });
}

// Header ASCII Art
const asciiArt = `
${chalk.cyanBright(`
 ██████╗ ███████╗███████╗██╗   ██╗██████╗ ███████╗██████╗ 
 ██╔══██╗╚══███╔╝██╔════╝██║   ██║██╔══██╗██╔════╝██╔══██╗
 ██████╔╝  ███╔╝ █████╗  ██║   ██║██████╔╝█████╗  ██████╔╝
 ██╔══██╗ ███╔╝  ██╔══╝  ██║   ██║██╔══██╗██╔══╝  ██╔══██╗
 ██████╔╝███████╗███████╗╚██████╔╝██████╔╝███████╗██║  ██║
 ╚═════╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
`)}

${chalk.bold.magenta('                TOOLS CREATE BASE BY DIKA')}
`;

async function setupBot() {
    console.clear();
    console.log(chalk.bold.green("\n🎉 === SELAMAT DATANG DI SETUP BOT WHATSAPP === 🎉\n"));
    console.log(asciiArt);

    // Meminta input dari pengguna
    const botName = await getInput(`${chalk.yellow("👉")} Nama Bot: `);
    const ownerName = await getInput(`${chalk.yellow("👉")} Nama Owner: `);
    const botNumber = await getInput(`${chalk.yellow("👉")} Nomor Bot (contoh: 628123456789): `);
    const ownerNumber = await getInput(`${chalk.yellow("👉")} Nomor Owner (contoh: 628987654321): `);
    const botVersion = await getInput(`${chalk.yellow("👉")} Versi Bot: `);
    const prefix = await getInput(`${chalk.yellow("👉")} Prefix (contoh: !): `);
    const usePairingCode = await getInput(`${chalk.yellow("👉")} Ingin menggunakan pairing code? [y/n]: `);

    let pairingCode = "12345678"; // Default pairing code
    if (usePairingCode.toLowerCase() === 'y') {
        pairingCode = await getInput(`${chalk.yellow("👉")} Masukkan custom pairing code (8 karakter): `);
        if (pairingCode.length !== 8) {
            console.log(chalk.red("[!] Pairing code harus 8 karakter. Menggunakan nilai default: 12345678"));
            pairingCode = "12345678";
        }
    }

    const useButtons = await getInput(`${chalk.yellow("👉")} Ingin menggunakan button interaktif? [y/n]: `);

    // Membuat folder sesuai nama bot
    const botFolder = botName.replace(/\s+/g, '_'); // Ganti spasi dengan underscore
    const botPath = path.join(process.cwd(), botFolder);

    if (!fs.existsSync(botPath)) {
        fs.mkdirSync(botPath);
        console.log(`\n${chalk.greenBright("✨")} Folder '${botFolder}' berhasil dibuat!`);
    } else {
        console.log(`\n${chalk.greenBright("✨")} Folder '${botFolder}' sudah ada. Melanjutkan...`);
    }

    // Membuat objek konfigurasi
    const config = {
        botName,
        ownerName,
        botNumber,
        ownerNumber,
        botVersion,
        prefix,
        usePairingCode: usePairingCode.toLowerCase() === 'y',
        pairingCode,
        useButtons: useButtons.toLowerCase() === 'y'
    };

    // Menyimpan konfigurasi ke file JSON
    const configPath = path.join(botPath, 'config.json');
    fs.writeFileSync(configPath, JSON.stringify(config, null, 4));
    console.log(`${chalk.greenBright("✨")} Konfigurasi berhasil disimpan di ${chalk.cyanBright(configPath)}\n`);

    // Template dasar case-a.js (Tanpa tombol)
    const caseATemplate = `
const config = require('./config.json');

module.exports = {
    messageHandler: async (sock, m) => {
        const msg = m.messages[0];
        if (!msg.message) return;

        const from = msg.key.remoteJid;
        const type = Object.keys(msg.message)[0];
        const content = (type === 'conversation') ? msg.message.conversation :
                       (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text : '';

        // Cek apakah pesan dimulai dengan prefix
        if (content.startsWith(config.prefix)) {
            const command = content.slice(config.prefix.length).trim();
            console.log(\`\n✨ [\${config.botName}] Command diterima: \${command}\`);

            // Handle commands
            switch (command) {
                case 'ping':
                    sock.sendMessage(from, { text: "Pong! Bot masih aktif." });
                    break;

                case 'owner':
                    sock.sendMessage(from, { text: \`Owner bot: \${config.ownerName} (\${config.ownerNumber})\` });
                    break;

                case 'bot':
                    sock.sendMessage(from, { text: \`Nama bot: \${config.botName}\\nVersi bot: \${config.botVersion}\` });
                    break;

                default:
                    sock.sendMessage(from, { text: \`Command tidak dikenali. Ketik \${config.prefix}ping untuk mencoba.\` });
                    break;
            }
        }
    }
};
`;

    // Template dasar case-b.js (Dengan tombol)
    const caseBTemplate = `
const config = require('./config.json');

module.exports = {
    messageHandler: async (sock, m) => {
        const msg = m.messages[0];
        if (!msg.message) return;

        const from = msg.key.remoteJid;

        // Fungsi untuk mendapatkan isi pesan
        const getBody = () => {
            if (m.mtype === "conversation") {
                return m.message.conversation;
            } else if (m.mtype === "imageMessage") {
                return m.message.imageMessage.caption;
            } else if (m.mtype === "videoMessage") {
                return m.message.videoMessage.caption;
            } else if (m.mtype === "extendedTextMessage") {
                return m.message.extendedTextMessage.text;
            } else if (m.mtype === "buttonsResponseMessage") {
                return m.message.buttonsResponseMessage.selectedButtonId;
            } else if (m.mtype === "listResponseMessage") {
                return m.message.listResponseMessage.singleSelectReply.selectedRowId;
            } else if (m.mtype === "interactiveResponseMessage") {
                return JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id;
            } else if (m.mtype === "templateButtonReplyMessage") {
                return m.message.templateButtonReplyMessage.selectedId;
            } else if (m.mtype === "messageContextInfo") {
                return (
                    m.message.buttonsResponseMessage?.selectedButtonId ||
                    m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
                    m.message.interactiveResponseMessage?.nativeFlowResponseMessage ||
                    m.text
                );
            } else {
                return m.text || "";
            }
        };

        const content = getBody();

        // Cek apakah pesan dimulai dengan prefix
        if (content.startsWith(config.prefix)) {
            const command = content.slice(config.prefix.length).trim();
            console.log(\`\n✨ [\${config.botName}] Command diterima: \${command}\`);

            // Handle commands
            switch (command) {
                case 'ping':
                    sock.sendMessage(from, { text: "Pong! Bot masih aktif." });
                    break;

                case 'owner':
                    sock.sendMessage(from, { text: \`Owner bot: \${config.ownerName} (\${config.ownerNumber})\` });
                    break;

                case 'bot':
                    sock.sendMessage(from, { text: \`Nama bot: \${config.botName}\\nVersi bot: \${config.botVersion}\` });
                    break;

                default:
                    sock.sendMessage(from, { text: \`Command tidak dikenali. Ketik \${config.prefix}ping untuk mencoba.\` });
                    break;
            }
        }

        // Handle button responses
        if (m.mtype === "buttonsResponseMessage" || m.mtype === "listResponseMessage" || m.mtype === "interactiveResponseMessage") {
            const buttonId = getBody(); // Mendapatkan ID tombol yang dipilih

            // Handle button IDs
            switch (buttonId) {
                case 'menu':
                    sock.sendMessage(from, {
                        text: "✅ *MENU UTAMA*\n\n" +
                              "1. Ketik *.ping* untuk cek status bot.\n" +
                              "2. Ketik *.owner* untuk info owner.\n" +
                              "3. Ketik *.bot* untuk info bot.",
                        footer: "© BOT BY DIKA",
                        buttons: [
                            { buttonId: ".ping", buttonText: { displayText: "Ping" }, type: 1 },
                            { buttonId: ".owner", buttonText: { displayText: "Owner" }, type: 1 },
                            { buttonId: ".bot", buttonText: { displayText: "Bot Info" }, type: 1 }
                        ],
                        headerType: 1
                    });
                    break;

                case 'ping':
                    sock.sendMessage(from, { text: "Pong! Bot masih aktif." });
                    break;

                case 'owner':
                    sock.sendMessage(from, { text: \`Owner bot: \${config.ownerName} (\${config.ownerNumber})\` });
                    break;

                case 'bot':
                    sock.sendMessage(from, { text: \`Nama bot: \${config.botName}\\nVersi bot: \${config.botVersion}\` });
                    break;

                default:
                    sock.sendMessage(from, { text: "ID tombol tidak dikenali." });
                    break;
            }
        }
    }
};
`;

    // Menyimpan file case.js berdasarkan pilihan tombol
    const casePath = path.join(botPath, 'case.js');
    if (useButtons.toLowerCase() === 'y') {
        fs.writeFileSync(casePath, caseBTemplate);
        console.log(`${chalk.greenBright("✨")} File case.js (dengan tombol) berhasil dibuat di ${chalk.cyanBright(casePath)}\n`);
    } else {
        fs.writeFileSync(casePath, caseATemplate);
        console.log(`${chalk.greenBright("✨")} File case.js (tanpa tombol) berhasil dibuat di ${chalk.cyanBright(casePath)}\n`);
    }

    // Template dasar index.js
    const indexTemplate = `
const { makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@fizzxydev/baileys-pro');
const pino = require('pino');
const readline = require('readline');
const chalk = require('chalk');
const { messageHandler } = require('./case');
const config = require('./config.json');

console.clear();
console.log(chalk.bgBlue.white.bold("══════════════════════════════════════"));
console.log(chalk.bgBlue.white.bold("         BASE BOT BY DIKA             "));
console.log(chalk.bgBlue.white.bold("══════════════════════════════════════"));
console.log(chalk.blueBright.bold("YouTube  : ") + chalk.white("[COMING SOON]"));
console.log(chalk.blueBright.bold("TikTok   : ") + chalk.white("[COMING SOON]"));
console.log(chalk.blueBright.bold("WhatsApp : ") + chalk.white(config.botNumber));
console.log(chalk.bgBlue.white.bold("══════════════════════════════════════"));
console.log(chalk.green.bold("Mau jasa buat base / tambah fitur?"));
console.log(chalk.green.bold("Hubungi WA di atas ya!\\n"));

async function connectToWhatsApp(usePairing) {
    let retryCount = 0;
    const maxRetries = 3;

    console.log(chalk.yellow(\`\${config.botName} START...\`));

    const { state, saveCreds } = await useMultiFileAuthState("./session");
    const sock = makeWASocket({
        logger: pino({ level: "fatal" }),
        auth: state,
        printQRInTerminal: !usePairing,
    });

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr }) => {
        if (qr && !usePairing) {
            console.log(chalk.bgGreen.black("\\n📌 SCAN QR CODE DI BAWAH INI:"));
            console.log(chalk.bgRed.white("\\n⚠️ SCAN SEBELUM 30 DETIK YAA ⚠️\\n"));
            console.log(qr);
        }

        if (connection === "close") {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect && retryCount < maxRetries) {
                console.log(chalk.red(\`❌ Koneksi terputus. Mencoba ulang (\${retryCount + 1}/\${maxRetries})...\`));
                retryCount++;
                connectToWhatsApp(usePairing);
            } else {
                console.log(chalk.red("❌ Gagal terhubung. Silakan coba lagi nanti."));
            }
        } else if (connection === "open") {
            retryCount = 0;
            console.log(chalk.green("✅ BOT BERHASIL TERHUBUNG!"));

            const senderJid = "\${config.botNumber}@s.whatsapp.net";
            const buttons = [{ buttonId: ".lmenu", buttonText: { displayText: "menu" }, type: 4 }];
            const message = {
                text: \`✅ *BOT BERHASIL TERHUBUNG!*\\n\\n\` +
                      \`🔹 *Bot Name:* \${config.botName}\\n\` +
                      \`🔹 *Developer:* Dika\\n\` +
                      \`🔹 *Status:* Aktif ✅\\n\\n\` +
                      \`Gunakan tombol di bawah untuk melihat semua fitur!\`,
                footer: "© BOT BY DIKA",
                buttons: buttons,
                headerType: 1,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterName: \`BOT BY DIKA \${config.botName}\`,
                        newsletterJid: "120363379582376036@newsletter",
                    },
                },
            };

            try {
                await sock.sendMessage(senderJid, message);
            } catch (error) {
                console.error(chalk.red("❌ Gagal mengirim pesan:", error.message || error));
            }
        }
    });

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("messages.upsert", async (m) => await messageHandler(sock, m));

    if (!sock.authState.creds?.registered && usePairing) {
        setTimeout(async () => {
            console.log(chalk.blue("🔍 Memulai proses request pairing code..."));

            // Gunakan nomor bot yang sudah dimasukkan sebelumnya
            const nomor = config.botNumber;

            if (!nomor.startsWith("62") || nomor.length < 10) {
                console.log(chalk.red("❌ Nomor tidak valid. Harus diawali '62' dan minimal 10 digit."));
                startBot();
                return;
            }

            console.log(chalk.cyan(\`📲 Nomor yang digunakan: \${nomor}\`));

            try {
                const code = await sock.requestPairingCode(nomor);
                console.log(chalk.bgGreen.black(\`✅ PAIRING CODE: \${code}\`));
                console.log(chalk.bgRed.white("⚠️ MASUKKAN PAIRING CODE DI WHATSAPP SEBELUM 30 DETIK ⚠️"));
            } catch (err) {
                console.error(chalk.bgRed.white("❌ Gagal mendapatkan pairing code:", err.message || err));
                startBot();
            }
        }, 2000);
    }
}

function startBot() {
    console.log(chalk.bgMagenta.white.bold("╔════════════════════════╗"));
    console.log(chalk.bgMagenta.white.bold("║   PILIH METODE LOGIN   ║"));
    console.log(chalk.bgMagenta.white.bold("╠════════════════════════╣"));
    console.log(chalk.magenta.bold("║ 1.") + chalk.white(" Pairing Code        ║"));
    console.log(chalk.magenta.bold("║ 2.") + chalk.white(" QR Code             ║"));
    console.log(chalk.bgMagenta.white.bold("╚════════════════════════╝"));

    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(chalk.cyan("MASUKAN PILIHAN ANDA : "), (choice) => {
        rl.close();
        if (choice === "1") {
            connectToWhatsApp(true);
        } else if (choice === "2") {
            connectToWhatsApp(false);
        } else {
            console.log(chalk.red("❌ Pilihan tidak valid, silakan coba lagi."));
            startBot();
        }
    });
}

startBot();
`;

    // Menyimpan file index.js
    const indexPath = path.join(botPath, 'index.js');
    fs.writeFileSync(indexPath, indexTemplate);
    console.log(`${chalk.greenBright("✨")} File index.js berhasil dibuat di ${chalk.cyanBright(indexPath)}\n`);

    // Instal modul secara otomatis
    const spinner = ora(`${chalk.greenBright("✨")} 📦 Menginisialisasi proyek Node.js...`).start();
    exec(`cd ${botPath} && npm init -y`, (initError) => {
        if (initError) {
            spinner.fail(`${chalk.red("[!]")} ❌ Gagal menginisialisasi proyek: ${initError.message}`);
            rl.close();
            return;
        }
        spinner.succeed(`${chalk.greenBright("✨")} ✅ Proyek berhasil diinisialisasi!`);

        const installSpinner = ora(`${chalk.greenBright("✨")} 📦 Menginstal modul @fizzxydev/baileys-pro...`).start();
        exec(`cd ${botPath} && npm install @fizzxydev/baileys-pro`, (installError) => {
            if (installError) {
                installSpinner.fail(`${chalk.red("[!]")} ❌ Gagal menginstal modul: ${installError.message}`);
                rl.close();
                return;
            }
            installSpinner.succeed(`${chalk.greenBright("✨")} ✅ Modul berhasil diinstal!`);

            // Tampilkan instruksi setelah selesai
            console.log(chalk.blueBright("\n───────────────────────────────────────────────────────"));
            console.log(chalk.greenBright("🎉 BASE BERHASIL DIBUAT! 🎉"));
            console.log(chalk.greenBright("=> Informasi yang Anda masukkan:"));
            console.log(chalk.greenBright(`   - Nama Bot: ${botName}`));
            console.log(chalk.greenBright(`   - Nama Owner: ${ownerName}`));
            console.log(chalk.greenBright(`   - Nomor Bot: ${botNumber}`));
            console.log(chalk.greenBright(`   - Versi Bot: ${botVersion}`));
            console.log(chalk.greenBright(`   - Prefix: ${prefix}`));
            console.log(chalk.greenBright(`   - Pairing Code: ${usePairingCode.toLowerCase() === 'y' ? 'Ya' : 'Tidak'}`));
            console.log(chalk.greenBright(`   - Button Interaktif: ${useButtons.toLowerCase() === 'y' ? 'Ya' : 'Tidak'}`));
            console.log(chalk.blueBright("───────────────────────────────────────────────────────"));
            console.log(chalk.yellow("👉 Untuk menjalankan bot:"));
            console.log(chalk.yellow(`   1. Masuk ke folder bot: cd ${botFolder}`));
            console.log(chalk.yellow(`   2. Jalankan bot: node index.js`));
            console.log(chalk.blueBright("───────────────────────────────────────────────────────"));
            console.log(chalk.magenta("                Proyek ini dibuat oleh Dika             "));
            console.log(chalk.blueBright("───────────────────────────────────────────────────────"));

            rl.close();
        });
    });
}

setupBot();
