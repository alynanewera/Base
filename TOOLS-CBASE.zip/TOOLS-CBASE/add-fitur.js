const fs = require('fs');
const readline = require('readline');
const path = require('path');
const chalk = require('chalk');

// Membuat interface untuk membaca input dari pengguna
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Fungsi untuk mendapatkan input dari pengguna
function getInput(prompt) {
    return new Promise((resolve) => {
        rl.question(prompt, (answer) => resolve(answer));
    });
}

// Header ASCII Art
const asciiArt = `
${chalk.cyanBright(`
██████╗  ██████╗ ██╗     ██╗   ██╗████████╗██╗ ██████╗ ███╗   ██╗
██╔══██╗██╔═══██╗██║     ██║   ██║╚══██╔══╝██║██╔═══██╗████╗  ██║
██████╔╝██║   ██║██║     ██║   ██║   ██║   ██║██║   ██║██╔██╗ ██║
██╔═══╝ ██║   ██║██║     ██║   ██║   ██║   ██║██║   ██║██║╚██╗██║
██║     ╚██████╔╝███████╗╚██████╔╝   ██║   ██║╚██████╔╝██║ ╚████║
╚═╝      ╚═════╝ ╚══════╝ ╚═════╝    ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
`)}

${chalk.bold.magenta('                TOOLS ADD FITUR BY DIKA')}
`;

async function addFitur() {
    console.log(chalk.bold.green("\n🎉 === SELAMAT DATANG DI TOOLS ADD FITUR BOT WHATSAPP === 🎉\n"));
    console.log(asciiArt);

    // Meminta nama bot yang ingin ditambahkan fitur
    const botFolderName = await getInput(`${chalk.yellow("👉")} Masukkan nama folder bot yang ingin ditambahkan fitur: `);
    const botPath = path.join(process.cwd(), botFolderName);

    // Periksa apakah folder bot ada
    if (!fs.existsSync(botPath)) {
        console.log(chalk.red(`[!] Folder '${botFolderName}' tidak ditemukan. Pastikan Anda memasukkan nama folder dengan benar.`));
        rl.close();
        return;
    }

    // Periksa apakah file case.js ada
    const casePath = path.join(botPath, 'case.js');
    if (!fs.existsSync(casePath)) {
        console.log(chalk.red(`[!] File 'case.js' tidak ditemukan di folder '${botFolderName}'. Pastikan bot telah dibuat dengan benar.`));
        rl.close();
        return;
    }

    // Baca isi file case.js
    let caseContent = fs.readFileSync(casePath, 'utf-8');

    // Daftar fitur yang bisa ditambahkan
    const availableFeatures = [
        { name: '.ping', code: `conn.sendMessage(from, \`Pong! Bot masih aktif.\`);` },
        { name: '.owner', code: `conn.sendMessage(from, \`Owner bot: \${config.ownerName} (\${config.ownerNumber})\`);` },
        { name: '.bot', code: `conn.sendMessage(from, \`Nama bot: \${config.botName}\\nVersi bot: \${config.botVersion}\`);` }
    ];

    // Tampilkan pilihan fitur
    console.log(chalk.green("\n✨ Pilih fitur yang ingin ditambahkan:"));
    console.log(chalk.yellow("   1. .ping"));
    console.log(chalk.yellow("   2. .owner"));
    console.log(chalk.yellow("   3. .bot"));
    console.log(chalk.yellow("   4. Semua fitur"));

    const choice = await getInput(`${chalk.yellow("👉")} Masukkan nomor pilihan (1/2/3/4): `);

    // Validasi pilihan
    if (!['1', '2', '3', '4'].includes(choice)) {
        console.log(chalk.red("[!] Pilihan tidak valid. Harap masukkan angka 1, 2, 3, atau 4."));
        rl.close();
        return;
    }

    // Tentukan fitur yang akan ditambahkan
    let selectedFeatures = [];
    if (choice === '1') {
        selectedFeatures.push(availableFeatures[0]);
    } else if (choice === '2') {
        selectedFeatures.push(availableFeatures[1]);
    } else if (choice === '3') {
        selectedFeatures.push(availableFeatures[2]);
    } else if (choice === '4') {
        selectedFeatures = availableFeatures;
    }

    // Cek apakah fitur sudah ada di file case.js
    for (const feature of selectedFeatures) {
        if (caseContent.includes(`case '${feature.name.replace('.', '')}':`)) {
            console.log(chalk.yellow(`[!] Fitur ${feature.name} sudah ada di file 'case.js'. Tidak perlu menambahkan ulang.`));
            selectedFeatures = selectedFeatures.filter(f => f !== feature);
        }
    }

    // Jika tidak ada fitur baru untuk ditambahkan
    if (selectedFeatures.length === 0) {
        console.log(chalk.yellow("[!] Tidak ada fitur baru yang dapat ditambahkan."));
        rl.close();
        return;
    }

    // Tambahkan fitur baru ke file case.js
    let newFeatures = '';
    for (const feature of selectedFeatures) {
        newFeatures += `
        case '${feature.name.replace('.', '')}':
            ${feature.code}
            break;
`;
    }

    caseContent = caseContent.replace(
        "default:",
        `${newFeatures}\n        default:`
    );

    // Simpan file case.js yang telah diperbarui
    fs.writeFileSync(casePath, caseContent);
    console.log(chalk.green(`✨ Fitur berhasil ditambahkan ke file 'case.js'!`));

    // Tampilkan instruksi
    console.log(chalk.blueBright("\n───────────────────────────────────────────────────────"));
    console.log(chalk.green("🎉 FITUR BERHASIL DITAMBAHKAN! 🎉"));
    console.log(chalk.yellow("👉 Untuk melihat fitur baru:"));
    console.log(chalk.yellow(`   1. Masuk ke folder bot: cd ${botFolderName}`));
    console.log(chalk.yellow(`   2. Jalankan bot: node index-qr.js atau node index-pairing.js`));
    console.log(chalk.yellow(`   3. Ketik salah satu command berikut:`));
    selectedFeatures.forEach(feature => {
        console.log(chalk.yellow(`      - ${feature.name}`));
    });
    console.log(chalk.blueBright("───────────────────────────────────────────────────────"));
    console.log(chalk.magenta("                Proyek ini dibuat oleh Dika             "));
    console.log(chalk.blueBright("───────────────────────────────────────────────────────"));

    rl.close();
}

addFitur();
