const fs = require('fs');
const readline = require('readline');
const path = '/sdcard/bahan';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const ask = (question) => new Promise(resolve => rl.question(question, resolve));

(async () => {
  console.clear();
  console.log('==== CREATE BASE WHATSAPP BOT ====');

  // Buat folder kalau belum ada
  if (!fs.existsSync(path)) {
    fs.mkdirSync(path, { recursive: true });
    console.log('[✓] Folder /sdcard/bahan dibuat');
  }

  // Input manual
  const namaBot = await ask('➤ Nama Bot: ');
  const namaOwner = await ask('➤ Nama Owner: ');
  const nomorOwner = await ask('➤ Nomor Owner (62xxx): ');
  const loginMode = await ask('➤ Login Mode (pairing/qrcode): ');
  const button = await ask('➤ Gunakan Button? (ya/tidak): ');

  // Template config.js
  const config = `module.exports = {
  namaBot: "${namaBot}",
  namaOwner: "${namaOwner}",
  nomorOwner: "${nomorOwner}",
  loginMode: "${loginMode}",
  useButton: ${button.toLowerCase() === 'ya'}
};`;

  // Simpan ke file
  const filePath = `${path}/config.js`;
  fs.writeFileSync(filePath, config);
  console.log(`\n[✓] config.js berhasil disimpan ke ${filePath}`);

  rl.close();
})();
